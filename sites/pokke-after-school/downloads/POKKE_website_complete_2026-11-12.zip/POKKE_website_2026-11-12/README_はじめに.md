# ポッケ放課後クラブ｜制作データ一式

保管日：2026年11月12日（日本時間）
版：画面全体の黄色い両開き扉から始まる公開版
公開元コミット：f603fb79517e5156b62de55f2f7bf5cc37a7156b

## まずサイトを見る

ZIPを展開し、`01_single-file/index.html` をChrome・Edge・Safariなどで開いてください。画像・CSS・JavaScriptはすべて内蔵済みです。この1ファイルだけ別の場所に移しても動きます。

## 編集する

`02_editable/` が編集用です。`index.html` にページ構成と原稿、`styles/site.css` にデザイン、`scripts/site.js` に動作、`scripts/entry.js` に初期表示の制御を分けています。画像は `assets/images/`、単独で開けるSVGキャラクターは `assets/characters/` です。フォルダの構造を保って編集してください。

`02_editable/index.html` も直接ブラウザで開けます。ローカルサーバーを利用する場合は、このZIPの展開先で `python3 -m http.server 8000` を実行し、`http://localhost:8000/02_editable/` を開きます。

## 編集後に1ファイル版を作り直す

Python 3の標準機能だけを使います。追加ライブラリ・npm・ビルドサービスは不要です。

```sh
python3 tools/build_single_file.py
```

`build/index.html` に、編集用の画像・CSS・JavaScriptを埋め込んだ新しい単体HTMLができます。元の `01_single-file/index.html` は保管用として上書きしません。

## 素材と資料

- `03_original-assets/`：AI生成時の原寸PNG2点。活動写真4点はコンタクトシートを4分割したものです。
- `04_documents/`：サイト構成、デザイン・動作仕様、素材生成メモ、コレクション登録例、検証範囲。
- `manifest.json`：公開元・保管日・ファイルの一覧とSHA-256。

## 公開

単体版は `index.html` を置くだけで公開できます。編集用をそのまま公開する場合は `02_editable/` の中身をフォルダ構造ごと配置してください。画面遷移はハッシュ（#aboutなど）なので、サーバー側の特別なルーティング設定は不要です。

GitHub Pages公開URL：
https://kenkenta51-max.github.io/SAMPLE-site/sites/pokke-after-school/

## デモの範囲

団体名・住所・料金・活動記録は架空です。写真はすべてAI生成画像です。見学フォームは入力→確認→完了の操作デモで、実際の送信・予約は行いません。入力値をサーバーや端末内ストレージへ保存しません。動きの軽減設定だけは端末内に保持します。

この保管データにはアカウント情報・認証情報・node_modules・他サイトのデータ・外部サービスの管理情報は含めていません。過去の試作版ではなく、公開した最新版と、その版を編集するためのデータを収録しています。
