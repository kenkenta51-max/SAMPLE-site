from pathlib import Path
import base64,re,mimetypes
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'02_editable'
html=(SOURCE/'index.html').read_text(encoding='utf-8')
def stylesheet(m):
 return '<style>'+ (SOURCE/m.group(1)).read_text(encoding='utf-8')+'</style>'
def script(m):
 return '<script>'+ (SOURCE/m.group(1)).read_text(encoding='utf-8')+'</script>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',stylesheet,html)
html=re.sub(r'<script src="([^"]+)"></script>',script,html)
for file in sorted((SOURCE/'assets/images').glob('*')):
 if not file.is_file():continue
 mime=mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
 data='data:'+mime+';base64,'+base64.b64encode(file.read_bytes()).decode('ascii')
 html=html.replace(file.relative_to(SOURCE).as_posix(),data)
out=ROOT/'build/index.html';out.parent.mkdir(exist_ok=True);out.write_text(html,encoding='utf-8')
print('Created:',out)
